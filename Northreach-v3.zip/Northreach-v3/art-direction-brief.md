# Northreach: Windward Edition

Player fantasy: an explorer awakening three coastal flames. Core verbs: explore,
strike, gather, dash, glide, climb, restore, rest. Three.js r187 / WebGL2, desktop
browser first, third-person orbit camera, responsive interface and touch controls.

The user's bright meadow/coast screenshots are the visual reference: flowing
grass, blue water, distant mountains, weathered stone and timber. The supplied
pixel-fantasy props remain recognizable. This is a browser-scale interpretation;
it does not reproduce the reference games' proprietary environments.

Visual priorities are a readable human silhouette, lush curved grass, rough
materials and a clear turquoise shard trail. Mint `#8deec9` marks collectibles,
warm gold `#c6b47d` marks navigation, weathered gray `#a3a58a` marks stone.
Sunlight comes from the upper left, with blue ambient sky and warm ground fill.
Wind moves grass and the canopy; only strong impacts move the camera. Reduced
motion disables impact shake. Keep implementation details out of the HUD.

Color tiles are opaque 1024×1024 RGB PNG, repeat wrapping with mipmaps and sRGB.
Water normals use linear data. Generated grass and water tiles derive from the
user's inline references; they are not byte-for-byte copies of the screenshots.
Opposite-edge pixels match after deterministic edge blending. Models use meters,
Y-up and authored internal transforms. Wrapper placement normalizes only the
whole model's horizontal center/bottom; assembled kit transforms are not reapplied.
The oversized arch is uniformly scaled to 0.16. A human is 1.82 m tall.

Near grass/trees use instancing, distant forest uses lower detail, and particles
use a fixed pool. High detail adds more grass, shadows and higher resolution.
The software preset lowers density, resolution and shadow cost. Upward-facing
mesh triangles supply bridge/scaffold support with gaps retained. Colliders have
vertical bounds so characters can move above small props.

Target selected by the agent from the provided references under the user's
request to improve the game. Agent inspected actual in-engine captures; user
visual approval has not been claimed. Asset sources and checks are recorded in
asset-manifest.json and ASSET-CREDITS.txt.
