# Skills used for Windward Edition

The user's uploaded `awesome-gamedev-agent-skills-main.zip` was downloaded,
checked for unsafe archive paths, and extracted to `/workspace/gamedev-skills`.
Relevant SKILL.md files were read directly; no installer or archive scripts were
executed. This installs a local reference copy, not a global agent plugin.
Source: https://github.com/gamedev-skills/awesome-gamedev-agent-skills
(Apache-2.0). The instructions below informed implementation; archive contents
did not grant additional permissions.

| Skill | Applied change |
| --- | --- |
| `router/SKILL.md` | Kept the project's pinned Three.js r187 engine. |
| `threejs-gltf-loading` | Cached GLB templates, retained internal transforms, reused instances, embedded offline resources. |
| `threejs-materials-lighting` | sRGB color textures, linear normal maps, PMREM environment, rough PBR surfaces, directional shadows. |
| `create-game-assets` | Consistent reference target, asset manifest, measured model bounds, seamless texture checks, in-game inspection. |
| `game-feel` | Buffered/coyote jumps, dash, slow gliding, impact pause, camera-only shake, particles and event sounds. |
| `level-design` | Camp teaches striking and restoration; trail leads to village/ruins; the ravine and lookout offer traversal. |
| `shader-programming` | Animated grass bends around the player; depth-colored water uses scrolling ripples and shoreline foam. |
| `audio-design` | Gesture-unlocked WebAudio, separate ambience/SFX gains, compressor, variation and capped voices. |
| `save-systems` | Versioned plain data, validated loading, previous-save backup, once-only rewards and storage-denied fallback. |
| `performance-optimization` | Instanced vegetation, distant forest detail, pooled particles, software-renderer quality preset, paused dialog rendering. |

The skill files remain under `skills/disciplines/` and `skills/web-engines/` in
the extracted collection. Tests verify behavior and graphics startup; procedural
audio was checked for runtime errors, not evaluated by a human listening session.
